# scoring_lock merge (HPC ↔ gpunode)

- **HPC:** `src/scoring_lock.py` — per-`(verifier, out)` flock under `.cache/score_locks/`.
- **gpunode:** same module also acquires `jobs/locks/gpu0_scoring.lock` when `MEDVERIF_GPU_GLOBAL_SCORE_LOCK` is not disabled (default **on**).

When merging branches, **do not replace** one side’s file wholesale. Keep:

1. gpunode’s `gpu0_scoring.lock` path and any gpunode-only helpers.
2. HPC’s hashed per-output locks (required for parallel OpenRouter / multi-out scoring).

Disable global GPU lock only for debugging: `MEDVERIF_GPU_GLOBAL_SCORE_LOCK=0`.
