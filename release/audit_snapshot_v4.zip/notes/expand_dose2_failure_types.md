# Expanded DOSE spot-check failure types (dose2 PI notes)

- Labeled rows: **54** (34 Y / 20 N → **63.0%** Y; gate **85%**).

## Tag counts (N rows; multi-tag allowed)

- **missing_drug_or_generic_subject**: 9
- **c0_context_stripped**: 3
- **non_dose_volume**: 3
- **other**: 3
- **thousands_separator_bug**: 2
- **weak_e1_contrast**: 2
- **threshold_context**: 1

## Examples

### c0_context_stripped
- **D0020**: [reviewer note withheld; tags: missing drug name; context dropped]
- **D0167**: [reviewer note withheld; tags: context dropped]
- **D0195**: [reviewer note withheld; tags: context dropped]

### missing_drug_or_generic_subject
- **D0020**: [reviewer note withheld; tags: missing drug name; context dropped]
- **D0079**: [reviewer note withheld; tags: missing drug name]
- **D0092**: [reviewer note withheld; tags: missing drug name]
- **D0155**: [reviewer note withheld; tags: missing drug name]
- **D0204**: [reviewer note withheld; cues: The specific drug]

### non_dose_volume
- **D0027**: [reviewer note withheld; tags: not a dose; exclude:]
- **D0122**: [reviewer note withheld; tags: not a dose; exclude:]
- **D0367**: [reviewer note withheld; tags: not a dose; exclude:]

### other
- **D0259**: [reviewer note withheld]
- **D0308**: [reviewer note withheld]
- **D0345**: [reviewer note withheld]

### thousands_separator_bug
- **D0043**: [reviewer note withheld; tags: number format error; cues: 1,2000]
- **D0140**: [reviewer note withheld; cues: 1,1000]

### threshold_context
- **D0212**: [reviewer note withheld; tags: threshold; uncertain contradiction; cues: The study; above]

### weak_e1_contrast
- **D0212**: [reviewer note withheld; tags: threshold; uncertain contradiction; cues: The study; above]
- **D0342**: [reviewer note withheld; tags: unclear contradiction]

