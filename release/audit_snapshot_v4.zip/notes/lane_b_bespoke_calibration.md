# Bespoke-MiniCheck-7B calibration vs gpunode

- **n (overlap):** 93
- **verdict agreement:** 98.9%
- **mean |Δscore|:** 0.0142
- **HPC rows scored:** 200
- **precision (sample row):** bf16 quantized=False
- **Proceed packs:** YES

