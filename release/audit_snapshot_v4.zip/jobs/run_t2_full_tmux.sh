#!/usr/bin/env bash
set -euo pipefail
ROOT=<repo>
SESSION=t2_full
if tmux has-session -t "${SESSION}" 2>/dev/null; then
  echo "tmux session ${SESSION} already running"
  exit 0
fi
tmux new-session -d -s "${SESSION}" "bash ${ROOT}/jobs/lib/openrouter_retry.sh ${ROOT}/jobs/run_t2_full_openrouter.sh"
echo "started tmux ${SESSION}"
