#!/usr/bin/env bash
# T8b: DISABLED (2026-09-29 PI review: 10/40 genuine mismatches, mostly trivial formatting).
set -euo pipefail
ROOT=<repo>
echo "T8b DISABLED: see notes/t8b_DROPPED.md and REPORT.md Threats (LLM-AggreFact mismatch detector dropped)."
exit 1

if [[ ! -f "${ROOT}/data/t8/aggrefact/dev.jsonl" ]]; then
  set -a && source ~/<secrets-dir>/openrouter.env && set +a
  python3 scripts/t8_download_aggrefact.py
fi

python3 scripts/t8b_build_supported_sample.py

INST="${ROOT}/data/t8/instances_aggrefact_t8b.jsonl"
RAW="${ROOT}/results/raw/t8"
mkdir -p "${RAW}"

set -a && source ~/<secrets-dir>/openrouter.env && set +a
export MEDVERIF_USE_OPENROUTER=1
export MEDVERIF_API_LEDGER=1
export MEDVERIF_V1B_PROVIDER=OpenAI
python3 scripts/t8_budget.py || exit 2
python3 src/score_jsonl.py --verifier v1b_medscore --instances "${INST}" --out "${RAW}/v1b_medscore_t8b.jsonl"

python3 scripts/t8b_report.py
echo "T8b v1b done — gpunode: jobs/run_t8b_aggrefact_gpunode.sh"
