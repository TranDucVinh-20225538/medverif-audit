#!/usr/bin/env bash
set -euo pipefail
ROOT=<repo>
J1="${1:-61555}"
J2="${2:-61549}"
echo "watch T15 jobs ${J1} ${J2} $(date -Is)"
while squeue -j "${J1},${J2}" -h 2>/dev/null | grep -q .; do
  sleep 120
done
cd "${ROOT}"
python3 scripts/t15_aggrefact_report.py | tee notes/t15_aggrefact_report_run.md
echo "t15_aggrefact_report done $(date -Is)"
