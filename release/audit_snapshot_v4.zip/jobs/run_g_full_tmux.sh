#!/usr/bin/env bash
set -euo pipefail
ROOT=<repo>
exec bash "${ROOT}/jobs/lib/openrouter_retry.sh" "${ROOT}/jobs/run_g_full.sh"
