#!/usr/bin/env bash
# After Slurm job 61555 (T15 base GPU) exits, submit Bespoke on computeC (avoid 3rd job on computeB).
set -euo pipefail
ROOT=<repo>
JOB="${1:-61555}"
echo "wait_t15_bespoke: watching job ${JOB} $(date -Is)"
while squeue -j "${JOB}" -h 2>/dev/null | grep -q .; do
  sleep 60
done
echo "job ${JOB} finished; submitting bespoke $(date -Is)"
cd "${ROOT}"
sbatch --nodelist=computeC jobs/run_main_ext_bespoke_gpu.sbatch
sbatch --nodelist=computeC jobs/run_t18_bespoke_gpu.sbatch
