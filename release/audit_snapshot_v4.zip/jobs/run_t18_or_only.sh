#!/usr/bin/env bash
# T18 OpenRouter judges only ($2 cap); parallel with other packs (per-pack score lock).
set -euo pipefail
ROOT=<repo>
source "${ROOT}/jobs/lib/flock.sh"
medverif_acquire_lock t18_or_score

cd "${ROOT}"
INST="${ROOT}/data/t18/instances_t18.jsonl"
RAW="${ROOT}/results/raw/t18"
mkdir -p "${RAW}"
LOG="${ROOT}/jobs/logs/t18_or_$(date +%Y%m%dT%H%M).log"
exec >>"${LOG}" 2>&1
echo "t18 OR start $(date -Is)"

set -a && source ~/<secrets-dir>/openrouter.env && set +a
export PYTHONPATH="${ROOT}/src"
export MEDVERIF_USE_OPENROUTER=1
export MEDVERIF_API_LEDGER=1
export MEDVERIF_GPU_GLOBAL_SCORE_LOCK=pack
export MEDVERIF_OR_MAX_INFLIGHT="${MEDVERIF_OR_MAX_INFLIGHT:-2}"
export MEDVERIF_T18_BUDGET_USD="${MEDVERIF_T18_BUDGET_USD:-2}"

for v in v1_medscore v4_ragas_nli; do
  python3 scripts/openrouter_budget.py || exit 2
  python3 scripts/t18_openrouter_budget.py 2>/dev/null || true
  python3 src/score_jsonl.py --verifier "${v}" --instances "${INST}" --out "${RAW}/${v}.jsonl"
done

python3 scripts/aggregate_api_cost.py 2>/dev/null || true
echo "t18 OR done $(date -Is)"
