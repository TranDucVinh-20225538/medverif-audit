#!/usr/bin/env bash
# Merge gpunode M1 scores, report before/after, build M1+ pending for gpunode.
set -euo pipefail
ROOT=<repo>
cd "${ROOT}"

/usr/bin/git fetch origin gpunode-results 2>/dev/null || true
for f in v2a_minicheck.jsonl v3_alignscore.jsonl; do
  if /usr/bin/git cat-file -e "origin/gpunode-results:results/raw_m1/${f}" 2>/dev/null; then
    /usr/bin/git show "origin/gpunode-results:results/raw_m1/${f}" > "results/raw_m1/${f}"
    echo "merged results/raw_m1/${f} from origin/gpunode-results"
  fi
done

python3 scripts/build_m1_pending_gpunode.py
python3 scripts/build_m1plus_pending_gpunode.py
python3 scripts/m1_before_after_report.py
python3 scripts/t1_cost_validity_report.py

echo "m1 analysis done $(date -Is)"
