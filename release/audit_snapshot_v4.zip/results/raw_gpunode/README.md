# Gpunode CPU verifier scores (`env=gpunode`)

Copied from `origin/gpunode-results` at commit `c48093bdc73a6b11161a26a2b11124a0e2ba5612`.

These files mirror `results/raw/**` layout from the Gpunode scoring environment.
They are **not** merged into `results/raw/` on master (HPC/OpenRouter scores stay authoritative there).

Rebuilt into `release/audit_snapshot.zip` under the `results/raw_gpunode/` prefix.

## POL flip-ok pending (42 rows, commit `c48093b`)

There are **no** separate `pol*.jsonl` score files on `gpunode-results`. POL pending
instances (`data/v3/instances_pol_flip_pending_gpunode.jsonl`, see
`notes/pol_flip_pending_gpunode_manifest.json`) were **appended into the root encoders**:

- `v2a_minicheck.jsonl`, `v3_alignscore.jsonl`
- `t6_*.jsonl` at repo root (MiniCheck / AlignScore / SummaC / HHEM / Granite / Bespoke)

Paper metrics for pack `pol` use those gpunode root files via `release/canonical_sources.tsv`.
