#!/usr/bin/env python3
"""Deprecated alias: use scripts/t4_eco_score_gpunode.py on gpunode."""

from __future__ import annotations

import runpy
from pathlib import Path

if __name__ == "__main__":
    runpy.run_path(
        str(Path(__file__).resolve().parent / "t4_eco_score_gpunode.py"),
        run_name="__main__",
    )
