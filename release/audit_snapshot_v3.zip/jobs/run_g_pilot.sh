#!/usr/bin/env bash
set -euo pipefail
ROOT=<repo>
# shellcheck source=jobs/lib/flock.sh
source "${ROOT}/jobs/lib/flock.sh"
medverif_acquire_lock g_pilot_openrouter

cd "${ROOT}"
set -a && source ~/kkk/openrouter.env && set +a
source <shared_apps>/apps/conda/etc/profile.d/conda.sh
conda activate vllm
export PYTHONPATH="${ROOT}/src"
export HF_HOME="${ROOT}/.cache/huggingface"
export HUGGINGFACE_HUB_CACHE="${HF_HOME}/hub"
export MEDVERIF_PARA_GEN_PROVIDER="${MEDVERIF_PARA_GEN_PROVIDER:-DeepInfra}"
export MEDVERIF_PARA_VAL_PROVIDER="${MEDVERIF_PARA_VAL_PROVIDER:-DeepInfra}"

LOG="${ROOT}/jobs/logs/g_pilot_$(date +%Y%m%dT%H%M).log"
exec >>"${LOG}" 2>&1
echo "g pilot start $(date -Is)"
python3 src/inv_paraphrase_openrouter.py
echo "g pilot done $(date -Is)"
