#!/usr/bin/env bash
# Lane B: T6-A CPU trio (+ V2a/V3) on login node; legacy checkers in cpuverif_legacy job.
set -euo pipefail
ROOT=<repo>
source "${ROOT}/jobs/lib/flock.sh"
medverif_acquire_lock lane_b_cpuverif

cd "${ROOT}"
LOG="${ROOT}/jobs/logs/lane_b_cpuverif_$(date +%Y%m%dT%H%M).log"
exec >>"${LOG}" 2>&1
echo "lane B start $(date -Is)"

source <shared_apps>/apps/conda/etc/profile.d/conda.sh
conda activate cpuverif
export PYTHONPATH="${ROOT}/src:${ROOT}/analysis:${ROOT}/scripts"
export CUDA_VISIBLE_DEVICES=""
export HF_HOME="${ROOT}/.cache/huggingface"
export HUGGINGFACE_HUB_CACHE="${HF_HOME}/hub"
export MEDVERIF_SCORE_FLUSH_EVERY=20
export MEDVERIF_LANE_B_ENV_PROFILE=cpuverif
export ALIGNScore_SRC="${ROOT}/.cache/src/AlignScore/src"
export PYTHONPATH="${ALIGNScore_SRC}:${PYTHONPATH}"

python3 -c "import summac" 2>/dev/null || PIP_INDEX_URL=https://pypi.org/simple PIP_EXTRA_INDEX_URL= pip install --index-url https://pypi.org/simple -r notes/cpuverif-pip-extras.txt

python3 scripts/lane_b_record_env.py --reason lane_b_job_start
python3 scripts/lane_b_build_packs.py

LEG="${ROOT}/results/raw/lane_b"
mkdir -p "${LEG}/calibration_200"
for f in "${LEG}"/t6_*.jsonl; do
  [[ -f "$f" ]] || continue
  base=$(basename "$f")
  [[ -f "${LEG}/calibration_200/${base}" ]] || mv "$f" "${LEG}/calibration_200/${base}"
done

score_pack() {
  local pack="$1"
  local inst="$2"
  echo "=== lane_b score pack=${pack} === $(date -Is)"
  python3 scripts/lane_b_score_pack.py --pack "${pack}" --instances "${inst}"
  /usr/bin/git -C "${ROOT}" add "results/raw/lane_b/${pack}" "notes/lane_b_packs.json" 2>/dev/null || true
  if /usr/bin/git -C "${ROOT}" diff --cached --quiet; then
    echo "lane B ${pack}: nothing to commit"
  else
    /usr/bin/git -C "${ROOT}" commit -m "$(cat <<EOF
feat(lane_b): HPC scores for ${pack} (cpuverif trio + V2a/V3)

env=hpc cpuverif; legacy checkers skipped.

EOF
)"
    /usr/bin/git -C "${ROOT}" push origin master || true
  fi
}

python3 scripts/lane_b_recalibrate.py --if-stale || {
  echo "Lane B PAUSED: cpuverif trio calibration agreement <97% (see notes/lane_b_calibration_agreement.md)"
  exit 0
}

score_pack main_e1_evid "${ROOT}/data/lane_b/main_e1_evid.jsonl"
python3 scripts/lane_b_calibration_report.py

score_pack t17_downdose "${ROOT}/data/v3/t17_downdose.jsonl"
score_pack t14_pending "${ROOT}/data/v3/instances_t14_pending_node30.jsonl"

export MEDVERIF_M1=1
python3 scripts/lane_b_build_m1_packs.py
score_pack m1_t7_e1_unit "${ROOT}/data/lane_b/m1_t7_e1_unit.jsonl"
score_pack m1_main_inv_e1_c0 "${ROOT}/data/lane_b/m1_main_inv_e1_c0.jsonl"

python3 scripts/build_e2_unit_instances.py 2>/dev/null || true
score_pack e2_unit "${ROOT}/data/e2/instances_e2_unit_t7.jsonl" || echo "WARN: e2_unit pack missing"

export MEDVERIF_M1=1
score_pack m1_plus_v2v3 "${ROOT}/data/lane_b/m1_plus_930.jsonl" || echo "WARN: m1_plus pack optional"

echo "lane B CPU queue done $(date -Is)"
echo "Legacy checkers: run jobs/run_lane_b_legacy_cpuverif.sh after cpuverif_legacy cal"
