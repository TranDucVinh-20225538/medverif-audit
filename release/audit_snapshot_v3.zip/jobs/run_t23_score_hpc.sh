#!/usr/bin/env bash
# T23: reasoning OR judges on frozen main (v6 + v1c); cap $5.
set -euo pipefail
ROOT=<repo>
source "${ROOT}/jobs/lib/flock.sh"
medverif_acquire_lock t23_hpc_score

cd "${ROOT}"
set -a && source ~/kkk/openrouter.env && set +a
export PYTHONPATH="${ROOT}/src"
export MEDVERIF_USE_OPENROUTER=1
export MEDVERIF_API_LEDGER=1
export MEDVERIF_GPU_GLOBAL_SCORE_LOCK=pack
export MEDVERIF_OR_MAX_INFLIGHT="${MEDVERIF_OR_MAX_INFLIGHT:-2}"
export MEDVERIF_T23_BUDGET_USD="${MEDVERIF_T23_BUDGET_USD:-5}"

INST="${ROOT}/data/v3/instances_main.jsonl"
RAW="${ROOT}/results/raw/t23"
mkdir -p "${RAW}"
LOG="${ROOT}/jobs/logs/t23_hpc_$(date +%Y%m%dT%H%M).log"
exec >>"${LOG}" 2>&1
echo "t23 start $(date -Is)"

while IFS=$'\t' read -r slug module or_model provider; do
  echo "=== ${slug} ==="
  python3 scripts/openrouter_budget.py || exit 2
  python3 scripts/t23_openrouter_budget.py || exit 2
  export MEDVERIF_V6_VERIFIER_SLUG="${slug}"
  export MEDVERIF_V6_OPENROUTER_MODEL="${or_model}"
  export MEDVERIF_V6_PROVIDER="${provider}"
  export MEDVERIF_V1C_OPENROUTER_MODEL="${or_model}"
  export MEDVERIF_V1C_PROVIDER="${provider}"
  python3 src/score_jsonl.py --verifier "${module}" --instances "${INST}" \
    --out "${RAW}/${slug}.jsonl" || exit 1
done < <(python3 - <<'PY'
import json
from pathlib import Path
ROOT = Path("<repo>")
models = json.loads((ROOT / "notes/t6_models.json").read_text())["t6b_openrouter"]
for m in models:
    print("\t".join([m["slug"], m["verifier_module"], m["openrouter_model"], m["provider"]]))
PY
)

python3 scripts/t23_openrouter_budget.py
echo "t23 done $(date -Is)"
